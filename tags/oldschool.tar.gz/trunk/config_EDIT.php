<?php
/**
 * Edit this and rename it to config.php to get everything working.
 */


$db_user = "";
$db_pass = "";

?>
